package game;

public class GameInitializer {

    //A palyak inicializalasa file-bol
    public void initMaps(String from){}

    //input: int count
    //method: Letrehoz, annyi Character-t, amennyi int erteke
    //return: void
    public void initCharacters(int count){}
}

